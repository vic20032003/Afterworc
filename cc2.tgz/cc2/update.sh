#!/bin/bash
# AfterWorc Control Center update 2 (message box). Replaces one frontend file
# and rebuilds only the website gateway. Undo: bash /root/cc-20261110/cc2/rollback.sh
set -euo pipefail
umask 077
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=${AW_ROOT:-/srv/afterworc}
NEXT=$ROOT/src/frontend/next
FILE=$NEXT/components/control-center.jsx
CT=${AW_GATEWAY_CONTAINER:-awgo-gateway-1}
SITE=${AW_SITE:-https://afterworc.com}
STATE=$HERE/state.env
BK=$HERE/backup
say() { echo; echo "== $*"; }
die() { echo; echo "STOPPED: $*"; echo "Nothing on the live site was changed."; exit 1; }

[ -e "$STATE" ] && die "this update is already installed. To undo: bash $HERE/rollback.sh"
say "1/6 Checks"
[ -f "$FILE" ] || die "the Control Center is not installed on this server"
[ "$(sha256sum "$FILE" | cut -c1-12)" = "${AW_SUM_CC:-78e566aad20d}" ] || die "control-center.jsx is not the version installed on 10 Nov"
docker inspect "$CT" >/dev/null 2>&1 || die "container $CT not found"
label() { docker inspect "$CT" --format "{{index .Config.Labels \"$1\"}}"; }
OLD_IMAGE=$(docker inspect "$CT" --format '{{.Config.Image}}')
PROJECT=$(label com.docker.compose.project)
SERVICE=$(label com.docker.compose.service)
FILES=$(label com.docker.compose.project.config_files)
WORKDIR=$(label com.docker.compose.project.working_dir)
ENVFILE=$(label com.docker.compose.project.environment_file)
[ -n "$ENVFILE" ] || ENVFILE=$ROOT/production.env
ENVFILE=${ENVFILE%%,*}
{ [ -n "$OLD_IMAGE" ] && [ -n "$PROJECT" ] && [ -n "$SERVICE" ] && [ -n "$FILES" ]; } || die "could not read how the gateway was started"
case "$OLD_IMAGE" in *-cc1) ;; *) die "the gateway does not run the Control Center build (-cc1); it runs $OLD_IMAGE";; esac
NEW_IMAGE=${OLD_IMAGE%-cc1}-cc2
[ -f "$ENVFILE" ] || die "settings file $ENVFILE not found"
ARGS=(-p "$PROJECT" --env-file "$ENVFILE")
IFS=',' read -ra LIST <<< "$FILES"
for f in "${LIST[@]}"; do [ -f "$f" ] || die "compose file $f not found"; ARGS+=(-f "$f"); done
code() { curl -s -o /dev/null -m 20 -w '%{http_code}' "$1" || true; }
[ "$(code "$SITE/")" = "200" ] || die "the site does not answer 200 right now; not touching it"
docker image inspect "$OLD_IMAGE" >/dev/null || die "the running image is missing, so there would be no way back"
AW_GATEWAY_IMAGE=$NEW_IMAGE docker compose "${ARGS[@]}" config 2>/dev/null | grep -q "image: $NEW_IMAGE" || die "the gateway image name cannot be set safely"
echo "running: $OLD_IMAGE   new: $NEW_IMAGE"

say "2/6 Backup (kept in $BK)"
mkdir -p "$BK"
cp -p "$FILE" "$BK/control-center.jsx"
cp -p "$ENVFILE" "$BK/production.env"

SWAPPED=0
undo() {
  trap - ERR INT TERM
  set +e
  echo; echo "!! Something failed. Putting everything back."
  cp -p "$BK/control-center.jsx" "$FILE"
  if [ "$SWAPPED" = 1 ]; then
    cd "$WORKDIR" 2>/dev/null || cd /
    AW_GATEWAY_IMAGE=$OLD_IMAGE docker compose "${ARGS[@]}" up -d --no-deps "$SERVICE" || echo "!! could not restart the previous gateway automatically. Run: bash $HERE/rollback.sh"
    sleep "${AW_WAIT:-20}"; echo "site answers: $(code "$SITE/")"
    rm -f "$HERE/rollback.env"
  fi
  echo "Rolled back. The site runs the previous version ($OLD_IMAGE)."
  exit 1
}
trap undo ERR INT TERM

say "3/6 Replacing the Control Center page"
cp "$HERE/components/control-center.jsx" "$FILE"
chmod 644 "$FILE"

say "4/6 Building (the live site keeps running)"
cd "$WORKDIR" 2>/dev/null || cd "$ROOT/src"
AW_GATEWAY_IMAGE=$NEW_IMAGE docker compose "${ARGS[@]}" build "$SERVICE"
docker image inspect "$NEW_IMAGE" >/dev/null

say "5/6 Switching the gateway"
{ echo "OLD_IMAGE='$OLD_IMAGE'"; echo "NEW_IMAGE='$NEW_IMAGE'"; echo "PROJECT='$PROJECT'"; echo "SERVICE='$SERVICE'"; echo "FILES='$FILES'"; echo "WORKDIR='$WORKDIR'"; echo "ENVFILE='$ENVFILE'"; echo "FILE='$FILE'"; echo "SITE='$SITE'"; } > "$HERE/rollback.env"
SWAPPED=1
AW_GATEWAY_IMAGE=$NEW_IMAGE docker compose "${ARGS[@]}" up -d --no-deps "$SERVICE"

say "6/6 Checking the site"
ok=0
for _ in $(seq 1 36); do
  sleep "${AW_WAIT:-5}"
  st=$(docker inspect "$CT" --format '{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' 2>/dev/null || echo gone)
  home=$(code "$SITE/"); me=$(code "$SITE/api/auth/me"); adm=$(code "$SITE/admin")
  echo "  $st  home=$home  api=$me  admin=$adm"
  case "$st" in running/healthy|running/none) ;; *) continue;; esac
  [ "$home" = "200" ] || continue
  case "$me" in 200|401) ;; *) continue;; esac
  case "$adm" in 200|302|303|307|308) ;; *) continue;; esac
  ok=1; break
done
[ "$ok" = 1 ] || { echo "the site did not come back healthy in 3 minutes"; false; }
[ "$(docker inspect "$CT" --format '{{.Config.Image}}')" = "$NEW_IMAGE" ]
trap - ERR INT TERM
grep -q '^AW_GATEWAY_IMAGE=' "$ENVFILE" && sed -i "s|^AW_GATEWAY_IMAGE=.*|AW_GATEWAY_IMAGE=$NEW_IMAGE|" "$ENVFILE"
mv "$HERE/rollback.env" "$STATE"
echo
echo "DONE. Update 2 is live: $SITE/admin"
echo "To undo this update only: bash $HERE/rollback.sh"
