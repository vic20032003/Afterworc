#!/bin/bash
# Undoes update 2 only: back to the Control Center as installed first (-cc1).
set -uo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
S=$HERE/state.env; [ -f "$S" ] || S=$HERE/rollback.env
[ -f "$S" ] || { echo "Nothing to undo: update 2 did not change the live site."; exit 0; }
# shellcheck disable=SC1090
. "$S"
BK=$HERE/backup
[ -f "$BK/control-center.jsx" ] || { echo "Backup file is missing in $BK. Stop and call Boris."; exit 1; }
docker image inspect "$OLD_IMAGE" >/dev/null 2>&1 || { echo "The previous image $OLD_IMAGE is gone. Stop and call Boris."; exit 1; }
cp -p "$BK/control-center.jsx" "$FILE"
grep -q "^AW_GATEWAY_IMAGE=$NEW_IMAGE\$" "$ENVFILE" && sed -i "s|^AW_GATEWAY_IMAGE=.*|AW_GATEWAY_IMAGE=$OLD_IMAGE|" "$ENVFILE"
ARGS=(-p "$PROJECT" --env-file "$ENVFILE")
IFS=',' read -ra LIST <<< "$FILES"
for f in "${LIST[@]}"; do ARGS+=(-f "$f"); done
cd "$WORKDIR" 2>/dev/null || cd /
AW_GATEWAY_IMAGE=$OLD_IMAGE docker compose "${ARGS[@]}" up -d --no-deps "$SERVICE" || { echo "Could not start the previous gateway. Call Boris."; exit 1; }
c=000
for _ in $(seq 1 24); do sleep "${AW_WAIT:-5}"; c=$(curl -s -o /dev/null -m 20 -w '%{http_code}' "$SITE/" || true); echo "  site answers: $c"; [ "$c" = "200" ] && break; done
mv "$S" "$HERE/undone-$(date -u +%Y%m%dT%H%M%SZ).env"
[ "$c" = "200" ] && echo "UNDONE. The site runs the previous version again." || echo "The previous gateway was started but the site does not answer 200 yet. Call Boris."
