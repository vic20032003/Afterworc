#!/bin/bash
# AfterWorc update 3: new specialist profile page and brief page.
# Replaces one public file (site.js) and its build manifest, layers that file
# onto the running API image, and proves the API program itself is unchanged
# before switching. Undo: bash /root/cc-20261110/cc3/rollback.sh
set -Eeuo pipefail
umask 077
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=${AW_ROOT:-/srv/afterworc}
FE=$ROOT/src/frontend
JS=$FE/public/assets/site.js
MF=$FE/next/generated/public-manifest.json
CT=${AW_API_CONTAINER:-awgo-api-1}
SITE=${AW_SITE:-https://afterworc.com}
STATE=$HERE/state.env
BK=$HERE/backup
TMP=$HERE/tmp
OLD_JS=f6170fa3d947340ed7ce1980038aab09c8f3ec75015af83f9d9801ae687d53e4
NEW_JS=3c5cc31297e07c802664039dd7e80fe87223e8491f792321229913e71c4df2c2
say() { echo; echo "== $*"; }
die() { echo; echo "STOPPED: $*"; echo "Nothing on the live site was changed."; exit 1; }
sum() { sha256sum "$1" | cut -d' ' -f1; }

[ -e "$STATE" ] && die "this update is already installed. To undo: bash $HERE/rollback.sh"
say "1/7 Checks"
[ "$(sum "$HERE/site.js")" = "$NEW_JS" ] || die "the new site.js in this package is damaged"
[ "$(sum "$JS")" = "$OLD_JS" ] || die "the live site.js is not the version this update was made from"
[ -f "$MF" ] || die "build manifest not found"
grep -q "$OLD_JS" "$MF" || die "the build manifest does not match the live site.js"
docker inspect "$CT" >/dev/null 2>&1 || die "container $CT not found"
label() { docker inspect "$CT" --format "{{index .Config.Labels \"$1\"}}"; }
OLD_IMAGE=$(docker inspect "$CT" --format '{{.Config.Image}}')
PROJECT=$(label com.docker.compose.project)
SERVICE=$(label com.docker.compose.service)
FILES=$(label com.docker.compose.project.config_files)
WORKDIR=$(label com.docker.compose.project.working_dir)
ENVFILE=$(label com.docker.compose.project.environment_file)
[ -n "$ENVFILE" ] || ENVFILE=$ROOT/production.env
ENVFILE=${ENVFILE%%,*}
{ [ -n "$OLD_IMAGE" ] && [ -n "$PROJECT" ] && [ -n "$SERVICE" ] && [ -n "$FILES" ]; } || die "could not read how the API was started"
case "$OLD_IMAGE" in *-pg1|*-pg2) die "the API already runs this update";; esac
NEW_IMAGE=$OLD_IMAGE-pg2
[ -f "$ENVFILE" ] || die "settings file $ENVFILE not found"
ARGS=(-p "$PROJECT" --env-file "$ENVFILE")
IFS=',' read -ra LIST <<< "$FILES"
for f in "${LIST[@]}"; do [ -f "$f" ] || die "compose file $f not found"; ARGS+=(-f "$f"); done
code() { curl -s -o /dev/null -m 20 -w '%{http_code}' "$1" || true; }
[ "$(code "$SITE/")" = "200" ] || die "the site does not answer 200 right now; not touching it"
[ "$(code "$SITE/api/specialists")" = "200" ] || die "the API does not answer 200 right now; not touching it"
docker image inspect "$OLD_IMAGE" >/dev/null || die "the running API image is missing, so there would be no way back"
AW_API_IMAGE=$NEW_IMAGE docker compose "${ARGS[@]}" config 2>/dev/null | grep -q "image: $NEW_IMAGE" || die "the API image name cannot be set safely"
FREE=$(df -Pm "$ROOT" | awk 'NR==2{print $4}')
[ "$FREE" -gt 5000 ] || die "less than 5 GB free disk"
echo "running: $OLD_IMAGE   new: $NEW_IMAGE   service: $SERVICE"

say "2/7 Backup (kept in $BK)"
mkdir -p "$BK" "$TMP"
cp -p "$JS" "$BK/site.js"; cp -p "$MF" "$BK/public-manifest.json"; cp -p "$ENVFILE" "$BK/production.env"

restore_files() { cp -p "$BK/site.js" "$JS"; cp -p "$BK/public-manifest.json" "$MF"; }
SWAPPED=0
undo() {
  trap - ERR INT TERM
  set +e
  echo; echo "!! Something failed. Putting everything back."
  restore_files
  if [ "$SWAPPED" = 1 ]; then
    cd "$WORKDIR" 2>/dev/null || cd /
    AW_API_IMAGE=$OLD_IMAGE docker compose "${ARGS[@]}" up -d --no-deps "$SERVICE" || echo "!! could not restart the previous API automatically. Run: bash $HERE/rollback.sh"
    sleep "${AW_WAIT:-25}"; echo "site answers: $(code "$SITE/")  api: $(code "$SITE/api/specialists")"
    rm -f "$HERE/rollback.env"
  fi
  rm -rf "$TMP"
  echo "Rolled back. The site runs the previous version ($OLD_IMAGE)."
  exit 1
}
trap undo ERR INT TERM

say "3/7 Putting the new page file in place"
cp "$HERE/site.js" "$JS"; chmod 644 "$JS"
cp "$HERE/public-manifest.json" "$MF"; chmod 644 "$MF"

say "4/7 Making the new API image: the running image plus the one page file"
# Not rebuilt from source: a rebuild would pick up a newer Go compiler and
# change the API program. This image is the running one with site.js replaced.
CTX=$HERE/ctx; rm -rf "$CTX"; mkdir -p "$CTX"
cp "$HERE/site.js" "$CTX/site.js"; chmod 644 "$CTX/site.js"
printf 'FROM %s\nCOPY site.js /app/public/assets/site.js\n' "$OLD_IMAGE" > "$CTX/Dockerfile"
docker build -q -t "$NEW_IMAGE" "$CTX"
rm -rf "$CTX"
docker image inspect "$NEW_IMAGE" >/dev/null

say "5/7 Proving that only the page file changed"
grab() { local c; c=$(docker create "$1"); docker cp "$c:/app/api" "$TMP/$2.api" >/dev/null; docker cp "$c:/app/public" "$TMP/$2.public" >/dev/null; docker rm "$c" >/dev/null; }
rm -rf "$TMP"; mkdir -p "$TMP"
grab "$OLD_IMAGE" old; grab "$NEW_IMAGE" new
if [ "$(sum "$TMP/old.api")" != "$(sum "$TMP/new.api")" ]; then echo "the API program in the new image differs from the running one; not switching"; false; fi
CHANGED=$(diff -rq "$TMP/old.public" "$TMP/new.public" | sed "s#$TMP/##g" || true)
echo "$CHANGED"
[ "$(printf '%s\n' "$CHANGED" | grep -c .)" = "1" ] || { echo "expected exactly one changed public file"; false; }
printf '%s\n' "$CHANGED" | grep -q 'old.public/assets/site.js and new.public/assets/site.js differ' || { echo "the changed file is not site.js"; false; }
[ "$(sum "$TMP/new.public/assets/site.js")" = "$NEW_JS" ]
rm -rf "$TMP"
echo "API program identical; only assets/site.js differs."

say "6/7 Switching the API to the new image (a few seconds)"
{ echo "OLD_IMAGE='$OLD_IMAGE'"; echo "NEW_IMAGE='$NEW_IMAGE'"; echo "PROJECT='$PROJECT'"; echo "SERVICE='$SERVICE'"; echo "FILES='$FILES'"; echo "WORKDIR='$WORKDIR'"; echo "ENVFILE='$ENVFILE'"; echo "JS='$JS'"; echo "MF='$MF'"; echo "SITE='$SITE'"; } > "$HERE/rollback.env"
SWAPPED=1
AW_API_IMAGE=$NEW_IMAGE docker compose "${ARGS[@]}" up -d --no-deps "$SERVICE"

say "7/7 Checking the site"
ok=0
for _ in $(seq 1 36); do
  sleep "${AW_WAIT:-5}"
  st=$(docker inspect "$CT" --format '{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' 2>/dev/null || echo gone)
  home=$(code "$SITE/"); me=$(code "$SITE/api/auth/me"); sp=$(code "$SITE/api/specialists"); br=$(code "$SITE/api/briefs")
  live=$(curl -s -m 20 "$SITE/assets/site.js" | sha256sum | cut -d' ' -f1)
  echo "  $st  home=$home  auth=$me  specialists=$sp  briefs=$br  page-file=$([ "$live" = "$NEW_JS" ] && echo new || echo old)"
  case "$st" in running/healthy|running/none) ;; *) continue;; esac
  [ "$home" = "200" ] && [ "$sp" = "200" ] && [ "$br" = "200" ] || continue
  case "$me" in 200|401) ;; *) continue;; esac
  [ "$live" = "$NEW_JS" ] || continue
  ok=1; break
done
[ "$ok" = 1 ] || { echo "the site did not come back healthy in 3 minutes"; false; }
[ "$(docker inspect "$CT" --format '{{.Config.Image}}')" = "$NEW_IMAGE" ]
trap - ERR INT TERM
grep -q '^AW_API_IMAGE=' "$ENVFILE" && sed -i "s|^AW_API_IMAGE=.*|AW_API_IMAGE=$NEW_IMAGE|" "$ENVFILE"
mv "$HERE/rollback.env" "$STATE"
echo
echo "DONE. The new profile and brief pages are live."
echo "To undo this update only: bash $HERE/rollback.sh"
