#!/bin/bash
# Undoes update 3 only: the profile and brief pages go back to how they were.
set -uo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
S=$HERE/state.env; [ -f "$S" ] || S=$HERE/rollback.env
[ -f "$S" ] || { echo "Nothing to undo: update 3 did not change the live site."; exit 0; }
# shellcheck disable=SC1090
. "$S"
BK=$HERE/backup
{ [ -f "$BK/site.js" ] && [ -f "$BK/public-manifest.json" ]; } || { echo "Backup files are missing in $BK. Stop and call Boris."; exit 1; }
docker image inspect "$OLD_IMAGE" >/dev/null 2>&1 || { echo "The previous image $OLD_IMAGE is gone. Stop and call Boris."; exit 1; }
cp -p "$BK/site.js" "$JS"; cp -p "$BK/public-manifest.json" "$MF"
grep -q "^AW_API_IMAGE=$NEW_IMAGE\$" "$ENVFILE" && sed -i "s|^AW_API_IMAGE=.*|AW_API_IMAGE=$OLD_IMAGE|" "$ENVFILE"
ARGS=(-p "$PROJECT" --env-file "$ENVFILE")
IFS=',' read -ra LIST <<< "$FILES"
for f in "${LIST[@]}"; do ARGS+=(-f "$f"); done
cd "$WORKDIR" 2>/dev/null || cd /
AW_API_IMAGE=$OLD_IMAGE docker compose "${ARGS[@]}" up -d --no-deps "$SERVICE" || { echo "Could not start the previous API. Call Boris."; exit 1; }
c=000
for _ in $(seq 1 24); do sleep "${AW_WAIT:-5}"; c=$(curl -s -o /dev/null -m 20 -w '%{http_code}' "$SITE/api/specialists" || true); echo "  api answers: $c"; [ "$c" = "200" ] && break; done
mv "$S" "$HERE/undone-$(date -u +%Y%m%dT%H%M%SZ).env"
[ "$c" = "200" ] && echo "UNDONE. The site runs the previous version again." || echo "The previous API was started but does not answer 200 yet. Call Boris."
