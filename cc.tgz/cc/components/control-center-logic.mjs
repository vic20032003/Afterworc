// Pure rules of the Control Center (no React, no network), so they can be
// tested with node --test. Rows are the users of GET /api/admin/overview.

// Queue stages, in the order shown: [label, colour].
export const STAGES = {
  decide: ['Waiting for your decision', '#9a6700'],
  incomplete: ['Waiting for the person', '#5b6b62'],
  approved: ['Approved', '#1a7f37'],
  hold: ['On hold', '#9a6700'],
  declined: ['Declined or closed', '#cf222e']
};

const idState = u => (u.verify && u.verify.id && u.verify.id.st) || '';
const submitted = u => !!(u.spec && u.spec.submitted_at && !u.spec.published);

/** The one stage of an account. Staff must act only in "decide". */
export function stageOf(u) {
  if (u.status === 'blocked' || u.status === 'closed' || u.closed_at) return 'declined';
  if (u.status === 'hold') return 'hold';
  if (idState(u) === 'pending' || submitted(u)) return 'decide';
  if ((u.spec && u.spec.published) || (u.level && u.level !== 'registered')) return 'approved';
  return 'incomplete';
}

/** Whole days the account has waited for staff (since the profile was sent, else since registration). */
export function waitingDays(u, now = Date.now()) {
  const since = (submitted(u) && u.spec.submitted_at) || u.created_at || now;
  return Math.max(0, Math.floor((now - since) / 864e5));
}

/**
 * What "Approve" does for this account, in order, and what still blocks it.
 * todo: 'id' (accept the ID document), 'level' (Registered → Verified),
 * 'publish' (make the submitted profile public). profile is the review
 * record (GET /api/staff/moderation/profiles/{id}) or null.
 */
export function approvalSteps(u, profile) {
  const todo = [], blockers = [];
  let later = '';
  if (u.status === 'blocked' || u.status === 'closed') return { todo, blockers: ['the account is ' + u.status], later };
  if (idState(u) === 'pending') todo.push('id');
  if (!u.level || u.level === 'registered') todo.push('level');
  const status = profile && profile.state && profile.state.status;
  if (status === 'submitted') {
    if (u.email_verified) todo.push('publish');
    else blockers.push('the e-mail address is not confirmed, so the profile cannot be published yet');
  } else if (status === 'draft') {
    later = 'The profile is still a draft. Publish it here once the person sends it for review.';
    blockers.push('the profile has not been sent for review');
  }
  if (!u.email_verified && status !== 'submitted') blockers.push('the e-mail address is not confirmed');
  return { todo, blockers, later };
}

/**
 * Whether a masked address from the mail log (for example v***@af***.com)
 * can be this e-mail address. Mask characters stand for any run of text.
 */
export function matchesMask(masked, email) {
  if (!masked || !email) return false;
  const a = String(masked).toLowerCase(), b = String(email).toLowerCase();
  if (a === b) return true;
  if (!/[*•…]/.test(a)) return false;
  const pattern = a.split(/[*•…]+/).map(part => part.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('.*');
  try { return new RegExp('^' + pattern + '$').test(b); } catch { return false; }
}

/** Dated events of one account, newest first. view and profile may be null. */
export function timelineOf(u, view, profile) {
  const out = [];
  const add = (at, text) => { const t = typeof at === 'number' ? at : Date.parse(at); if (Number.isFinite(t) && t > 0) out.push({ at: t, text }); };
  add(u.created_at, 'Registered');
  if (u.spec && u.spec.submitted_at) add(u.spec.submitted_at, 'Sent the profile for review');
  if (u.verified_at) add(u.verified_at, 'Verification level set to ' + u.level + (u.verified_by ? ' by ' + u.verified_by : ''));
  if (view && view.moderation) add(view.moderation.changedAt, 'Account set to ' + view.moderation.status + ' (' + view.moderation.reason + ')');
  if (view && view.verification && view.verification.updatedAt) add(view.verification.updatedAt, 'Checks updated');
  const decision = profile && profile.state && profile.state.decision;
  if (decision) add(decision.decidedAt, 'Profile ' + decision.decision + (decision.reason ? ' (' + decision.reason + ')' : ''));
  return out.sort((a, b) => b.at - a.at);
}
