'use client';

// Control Center: the starting point for every incoming registration.
// One queue of all accounts with what each is waiting for, and one record per
// person (checks, ID document, profile, messages, e-mails, timeline) where
// staff approve, ask for changes, hold or block.
//
// It reads the same data as the staff console (GET /api/admin/overview) and
// changes things through the same audited routes (POST /api/admin/action and
// the Go moderation routes). Go re-checks the session, MFA and the staff
// grants on every call, so this page adds no new powers.

import { useCallback, useEffect, useMemo, useState } from 'react';
import { stageOf, STAGES, waitingDays, matchesMask, timelineOf, approvalSteps } from './control-center-logic.mjs';

const css = {
  wrap: { maxWidth: 1180, margin: '0 auto', padding: '24px 16px 96px', font: '14px/1.5 Inter, system-ui, sans-serif', color: 'var(--ink, #14211b)' },
  card: { background: 'var(--card, #fff)', border: '1px solid var(--line, #dfe5e1)', borderRadius: 14, padding: 16 },
  btn: { font: 'inherit', cursor: 'pointer', borderRadius: 10, padding: '7px 12px', border: '1px solid var(--line, #c9d3cd)', background: 'var(--card, #fff)', color: 'inherit' },
  primary: { background: '#065132', color: '#fff', borderColor: '#065132' },
  danger: { color: '#cf222e', borderColor: '#cf222e' },
  chip: on => ({ font: 'inherit', cursor: 'pointer', borderRadius: 99, padding: '5px 12px', border: '1px solid ' + (on ? '#065132' : 'var(--line, #c9d3cd)'), background: on ? '#e6f2ec' : 'transparent', color: 'inherit' }),
  inp: { font: 'inherit', width: '100%', boxSizing: 'border-box', padding: '8px 10px', borderRadius: 10, border: '1px solid var(--line, #c9d3cd)', background: 'var(--card, #fff)', color: 'inherit' },
  muted: { color: 'var(--muted, #5b6b62)' },
  th: { padding: '10px 12px', fontWeight: 500, textAlign: 'left' },
  td: { padding: '10px 12px', verticalAlign: 'top' },
  h3: { margin: '0 0 10px', fontSize: 15 }
};
const LEVEL = { registered: 'Registered', verified: 'Verified', checked: 'Worc-Checked' };
const STEP_NAME = { id: 'ID document', skills: 'Skills', refs: 'References', interview: 'Interview', checked: 'Worc-Checked' };
const RETURN_REASONS = [['incomplete', 'Profile is incomplete'], ['quality', 'Needs better wording or detail'], ['skills', 'Skills need correcting'], ['rate', 'Rate needs correcting'], ['policy', 'Breaks our rules'], ['other', 'Other']];
const STATUS_REASONS = [['identity_check', 'Identity check'], ['policy_violation', 'Rule violation'], ['fraud_suspected', 'Suspected fraud'], ['payment_issue', 'Payment issue'], ['user_request', 'User asked'], ['other', 'Other']];
const CODES = { state_conflict: 'This cannot be done in the current state. Refresh and check the record.', stale_review: 'The profile changed in the meantime. Refresh and try again.',
  mfa_required: 'Two-factor sign-in is required for this action.', forbidden: 'Your staff role does not allow this action.', not_found: 'Not found.' };

async function request(path, body, coded) {
  const r = await fetch(path, { method: body ? 'POST' : 'GET', credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'afterworc' }, body: body ? JSON.stringify(body) : undefined });
  let d = null;
  try { d = await r.json(); } catch { /* empty */ }
  // The console action route already answers with a sentence; the Go
  // moderation routes answer with a code, worded here.
  if (!r.ok) throw new Error((d && ((coded && CODES[d.code]) || d.error)) || 'Something went wrong. Try again.');
  return d;
}
const act = (type, payload) => request('/api/admin/action', { type, ...payload });
const mod = (path, body) => request('/api/staff/moderation' + path, body, true);

const day = ms => { try { return new Date(ms).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }); } catch { return ''; } };
const Pill = ({ text, color }) => <span style={{ fontSize: 12, fontWeight: 600, padding: '2px 9px', borderRadius: 99, border: '1px solid currentColor', color, whiteSpace: 'nowrap' }}>{text}</span>;
const Check = ({ ok, wait, label }) => <span title={label} style={{ whiteSpace: 'nowrap', color: ok ? '#1a7f37' : wait ? '#9a6700' : 'var(--muted, #5b6b62)' }}>{ok ? '✓' : wait ? '●' : '○'} {label}</span>;

function Checks({ u }) {
  const s = u.spec;
  return <span style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
    <Check ok={!!u.email_verified} label="E-mail" />
    {s && <Check ok={!!s.published} wait={!s.published && !!s.submitted_at} label={s.published ? 'Profile live' : s.submitted_at ? 'Profile sent' : 'Profile draft'} />}
    <Check ok={u.verify?.id?.st === 'done'} wait={u.verify?.id?.st === 'pending'} label={u.verify?.id?.st === 'pending' ? 'ID to check' : 'ID'} />
  </span>;
}

function Queue({ users, onOpen }) {
  const [filter, setFilter] = useState('decide');
  const [q, setQ] = useState('');
  const rows = useMemo(() => users.map(u => ({ u, stage: stageOf(u) })), [users]);
  const counts = useMemo(() => Object.fromEntries(Object.keys(STAGES).map(k => [k, rows.filter(r => r.stage === k).length])), [rows]);
  const needle = q.trim().toLowerCase();
  const shown = rows.filter(r => (needle ? true : !filter || r.stage === filter))
    .filter(r => !needle || [r.u.name, r.u.email, '#' + r.u.id, String(r.u.id)].some(v => String(v || '').toLowerCase().includes(needle)))
    .sort((a, b) => filter === 'decide' && !needle ? waitingDays(b.u) - waitingDays(a.u) : b.u.created_at - a.u.created_at);
  return <>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(150px,1fr))', gap: 10, marginBottom: 14 }}>
      {Object.entries(STAGES).map(([k, [label, color]]) => <button key={k} onClick={() => { setFilter(k); setQ(''); }} style={{ ...css.card, cursor: 'pointer', textAlign: 'left', font: 'inherit', color: 'inherit', borderColor: filter === k && !needle ? '#065132' : undefined }}>
        <div style={{ fontSize: 26, fontWeight: 700, color }}>{counts[k]}</div><div style={css.muted}>{label}</div></button>)}
    </div>
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
      <input style={{ ...css.inp, maxWidth: 340 }} placeholder="Search name, e-mail or account number" value={q} onChange={e => setQ(e.target.value)} />
      <button style={css.chip(!filter && !needle)} onClick={() => { setFilter(''); setQ(''); }}>Everyone ({users.length})</button>
    </div>
    <div style={{ ...css.card, padding: 0, overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 820 }}>
        <thead><tr style={css.muted}>{['Person', 'Type', 'Registered', 'Checks', 'Status', ''].map(h => <th key={h} style={css.th}>{h}</th>)}</tr></thead>
        <tbody>{shown.map(({ u, stage }) => <tr key={u.id} style={{ borderTop: '1px solid var(--line, #dfe5e1)', cursor: 'pointer' }} onClick={() => onOpen(u.id)}>
          <td style={css.td}><b>{u.name || 'No name'}</b> <span style={css.muted}>#{u.id}</span><div style={css.muted}>{u.email}</div></td>
          <td style={css.td}>{u.spec ? 'Specialist' : u.role_pref === 'specialist' ? 'Specialist (no profile yet)' : 'Business'}{u.is_admin ? ' · staff' : ''}</td>
          <td style={{ ...css.td, whiteSpace: 'nowrap' }}>{day(u.created_at)}</td>
          <td style={css.td}><Checks u={u} /></td>
          <td style={css.td}><Pill text={STAGES[stage][0]} color={STAGES[stage][1]} />{stage === 'decide' && <div style={css.muted}>waiting {waitingDays(u)} d</div>}</td>
          <td style={css.td}><button style={css.btn} onClick={e => { e.stopPropagation(); onOpen(u.id); }}>Open</button></td>
        </tr>)}</tbody>
      </table>
      {shown.length === 0 && <p style={{ ...css.muted, padding: 12, margin: 0 }}>{needle ? 'Nobody matches this search.' : 'Nobody here. Nothing is waiting.'}</p>}
    </div>
    {users.length >= 500 && <p style={css.muted}>Showing the 500 newest accounts. Search covers these only.</p>}
  </>;
}

function Record({ u, data, onBack, reload }) {
  const [view, setView] = useState(null);       // account review record
  const [profile, setProfile] = useState(null); // specialist profile, or false when there is none
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [ask, setAsk] = useState(null);         // null | 'return' | 'hold' | 'blocked'
  const [reason, setReason] = useState('');
  const [text, setText] = useState('');
  const load = useCallback(async () => {
    setError('');
    try { setView(await mod('/accounts/' + u.id)); } catch (e) { setError(e.message); }
    if (u.spec) { try { setProfile(await mod('/profiles/' + u.id)); } catch { setProfile(false); } } else setProfile(false);
  }, [u.id, u.spec]);
  useEffect(() => { load(); }, [load]);

  const run = async (fn, done) => {
    setBusy(true); setError(''); setNote('');
    try { await fn(); setNote(done); setAsk(null); setText(''); await reload(); await load(); }
    catch (e) { setError(e.message); await reload(); await load(); } finally { setBusy(false); }
  };
  const steps = approvalSteps(u, profile || null);
  const approve = () => run(async () => {
    for (const s of steps.todo) {
      if (s === 'id') await act('verify_set', { userId: u.id, key: 'id', st: 'done' });
      if (s === 'level') await act('user_level', { userId: u.id, level: 'verified', by: '' });
      if (s === 'publish') await mod('/profiles/' + u.id + '/publish', { version: profile.version });
    }
  }, steps.todo.includes('publish') ? 'Approved. The profile is live and the person was notified.' : 'Approved.' + (steps.later ? ' ' + steps.later : ''));
  const confirm = () => {
    if (ask === 'return') return run(() => mod('/profiles/' + u.id + '/return', { reason, version: profile.version }), 'Sent back for changes. The person was notified.');
    return run(() => act('user_status', { userId: u.id, status: ask, reason, note: text.trim() }), ask === 'hold' ? 'Account put on hold.' : 'Account blocked.');
  };
  const open = (kind, reasons) => { setAsk(kind); setReason(reasons[0][0]); setText(''); };

  const evidence = view?.verification?.evidenceFileId;
  const threads = (data.threads || []).filter(t => t.userId === u.id);
  const mails = (data.outbox || []).filter(m => matchesMask(m.to_addr, u.email));
  const events = timelineOf(u, view, profile || null);
  const stage = stageOf(u);
  const section = { ...css.card, display: 'grid', gap: 8 };
  return <div style={{ display: 'grid', gap: 14 }}>
    <div><button style={css.btn} onClick={onBack}>← All registrations</button></div>
    <div style={{ ...css.card, display: 'flex', justifyContent: 'space-between', gap: 14, flexWrap: 'wrap' }}>
      <div>
        <h2 style={{ margin: 0, fontSize: 22 }}>{u.name || 'No name'} <span style={{ ...css.muted, fontWeight: 400 }}>#{u.id}</span></h2>
        <div style={css.muted}>{u.email} · {u.spec ? 'Specialist' : 'Business'} · registered {day(u.created_at)} · {LEVEL[u.level] || u.level}{u.twofa ? ' · 2FA on' : ''}</div>
        {u.status_note && <div style={{ marginTop: 6 }}>Staff note: {u.status_note}</div>}
      </div>
      <div style={{ display: 'grid', gap: 6, justifyItems: 'end', alignContent: 'start' }}><Pill text={STAGES[stage][0]} color={STAGES[stage][1]} /><span style={css.muted}>Account: {u.status}</span></div>
    </div>
    {error && <div role="alert" style={{ ...css.card, borderColor: '#cf222e', color: '#cf222e' }}>{error}</div>}
    {note && <div role="status" style={{ ...css.card, borderColor: '#1a7f37', color: '#1a7f37' }}>{note}</div>}

    <div style={section}>
      <h3 style={css.h3}>Decision</h3>
      {steps.blockers.length > 0 && <div style={{ color: '#9a6700' }}>Before this person can go live: {steps.blockers.join('; ')}.</div>}
      {!ask && <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {u.status !== 'blocked' && u.status !== 'closed' && <button disabled={busy || steps.todo.length === 0} style={{ ...css.btn, ...css.primary }} onClick={approve}>{steps.todo.includes('publish') ? 'Approve and publish' : 'Approve'}</button>}
        {profile && profile.state?.status === 'submitted' && <button disabled={busy} style={css.btn} onClick={() => open('return', RETURN_REASONS)}>Ask for changes</button>}
        {u.status === 'active' && <button disabled={busy} style={css.btn} onClick={() => open('hold', STATUS_REASONS)}>Put on hold</button>}
        {(u.status === 'active' || u.status === 'hold') && <button disabled={busy} style={{ ...css.btn, ...css.danger }} onClick={() => open('blocked', STATUS_REASONS)}>Decline and block</button>}
        {(u.status === 'hold' || u.status === 'blocked') && <button disabled={busy} style={css.btn} onClick={() => run(() => act('user_status', { userId: u.id, status: 'active' }), 'Account reactivated.')}>Reactivate</button>}
      </div>}
      {steps.todo.length === 0 && !ask && u.status === 'active' && <div style={css.muted}>{steps.later || 'Nothing left to approve.'}</div>}
      {ask && <div style={{ display: 'grid', gap: 8, maxWidth: 560 }}>
        <b>{ask === 'return' ? 'What should the person change?' : ask === 'hold' ? 'Why is the account put on hold?' : 'Why is this person declined?'}</b>
        <select style={css.inp} value={reason} onChange={e => setReason(e.target.value)}>{(ask === 'return' ? RETURN_REASONS : STATUS_REASONS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
        {ask !== 'return' && <textarea rows={2} maxLength={500} style={css.inp} placeholder="Note for the team (the person does not see it)" value={text} onChange={e => setText(e.target.value)} />}
        {ask === 'blocked' && <div style={{ color: '#cf222e' }}>The person will not be able to sign in. You can reactivate the account later.</div>}
        <div style={{ display: 'flex', gap: 8 }}>
          <button disabled={busy} style={{ ...css.btn, ...(ask === 'blocked' ? css.danger : css.primary) }} onClick={confirm}>{ask === 'return' ? 'Send back for changes' : ask === 'hold' ? 'Put on hold' : 'Decline and block'}</button>
          <button style={css.btn} onClick={() => setAsk(null)}>Cancel</button>
        </div>
      </div>}
    </div>

    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))', gap: 14 }}>
      <div style={section}>
        <h3 style={css.h3}>Checks and documents</h3>
        <Check ok={!!u.email_verified} label={u.email_verified ? 'E-mail confirmed' : 'E-mail not confirmed yet'} />
        {Object.keys(STEP_NAME).map(k => { const st = u.verify?.[k]?.st; return <Check key={k} ok={st === 'done'} wait={st === 'pending'} label={STEP_NAME[k] + ': ' + (st === 'done' ? 'done' : st === 'pending' ? 'waiting for us' : 'not started')} />; })}
        {evidence ? <a href={'/api/files/' + evidence} target="_blank" rel="noopener noreferrer" style={{ ...css.btn, ...css.primary, textDecoration: 'none', justifySelf: 'start' }}>Open the ID document</a>
          : <span style={css.muted}>{u.verify?.id?.st === 'done' ? 'The ID was checked. The document is no longer shown after the check.' : 'No ID document is waiting.'}</span>}
        {(u.verify?.refs?.refs || []).map((r, i) => <div key={i}>Referee: {r.name}, {r.company} · {r.email}</div>)}
        {u.verified_by && <div style={css.muted}>Checked by {u.verified_by}{u.verifiedOn ? ' on ' + u.verifiedOn : ''}</div>}
      </div>
      <div style={section}>
        <h3 style={css.h3}>Profile form</h3>
        {profile === null ? <span style={css.muted}>Loading…</span> : !profile ? <span style={css.muted}>{u.spec ? 'The profile could not be read.' : 'This account has no specialist profile.'}</span> : <>
          <div><b>{profile.headline || 'No headline yet'}</b> <span style={css.muted}>· {profile.state?.status}</span></div>
          <div style={css.muted}>{[profile.city, profile.rateEur != null ? '€' + profile.rateEur + '/h' : '', profile.hoursPerWeek ? profile.hoursPerWeek + ' h/week' : '', profile.availability].filter(Boolean).join(' · ')}</div>
          <div style={{ whiteSpace: 'pre-wrap' }}>{profile.about || 'No about text yet.'}</div>
          <div>{(profile.skills || []).map(s => <span key={s.name} style={{ display: 'inline-block', margin: '0 6px 6px 0', padding: '2px 9px', borderRadius: 99, border: '1px solid var(--line, #c9d3cd)', color: s.pending ? '#9a6700' : undefined }}>{s.name}{s.pending ? ' (new, to check)' : ''}</span>)}</div>
          {profile.portfolioUrl && <a href={profile.portfolioUrl} target="_blank" rel="noopener noreferrer nofollow">{profile.portfolioUrl}</a>}
          {profile.state?.decision && <div style={css.muted}>Last decision: {profile.state.decision.decision}{profile.state.decision.reason ? ' (' + profile.state.decision.reason + ')' : ''}</div>}
        </>}
      </div>
    </div>

    <div style={section}>
      <h3 style={css.h3}>Messages ({threads.length})</h3>
      {threads.length === 0 ? <span style={css.muted}>No conversations with this person.</span> : threads.map(t => <div key={t.id} style={{ borderTop: '1px solid var(--line, #dfe5e1)', paddingTop: 8 }}>
        <b>{t.title}</b> <span style={css.muted}>· {t.at}{t.unread ? ' · ' + t.unread + ' unread' : ''}</span>
        {(t.msgs || []).map((m, i) => <div key={i} style={{ margin: '4px 0' }}><span style={css.muted}>{m.f === 'user' ? u.name || 'User' : m.f === 'staff' ? 'AfterWorc' : 'System'} · {m.tm}:</span> {m.t}</div>)}
        {(t.msgs || []).length === 0 && <div style={css.muted}>Open the Staff console inbox to read this conversation.</div>}
      </div>)}
      {threads.length > 0 && <a href="#/">Reply in the Staff console</a>}
    </div>

    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(320px,1fr))', gap: 14 }}>
      <div style={section}>
        <h3 style={css.h3}>E-mails we sent ({mails.length})</h3>
        {mails.length === 0 ? <span style={css.muted}>No recent e-mails found for this address.</span> : mails.map(m => <div key={m.id}>{m.subject} <span style={css.muted}>· {m.status} · {m.at}</span></div>)}
        <span style={css.muted}>From the recent mail log, matched by the hidden address. Message texts are not stored.</span>
      </div>
      <div style={section}>
        <h3 style={css.h3}>Timeline</h3>
        {events.map((e, i) => <div key={i}><span style={css.muted}>{day(e.at)}</span> · {e.text}</div>)}
      </div>
    </div>
  </div>;
}

export default function ControlCenter() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [openId, setOpenId] = useState(null);
  const load = useCallback(async () => {
    try { setData(await request('/api/admin/overview')); setError(''); } catch (e) { setError(e.message); }
  }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const sync = () => { const m = window.location.hash.match(/^#\/control\/u\/(\d+)$/); setOpenId(m ? Number(m[1]) : null); };
    sync();
    window.addEventListener('hashchange', sync);
    return () => window.removeEventListener('hashchange', sync);
  }, []);
  const go = id => { window.location.hash = id ? '#/control/u/' + id : '#/control'; };
  const users = data?.users || [];
  const current = openId ? users.find(u => u.id === openId) : null;
  return <div style={css.wrap}>
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'end', gap: 12, flexWrap: 'wrap', marginBottom: 16 }}>
      <div><div style={{ ...css.muted, fontSize: 12, letterSpacing: '.08em', textTransform: 'uppercase' }}>Staff console</div><h1 style={{ margin: '4px 0 0', fontSize: 26 }}>Control Center</h1>
        <p style={{ ...css.muted, margin: '4px 0 0' }}>Every registration and upload lands here. Open a person to see everything about them and decide.</p></div>
      <button style={css.btn} onClick={load}>Refresh</button>
    </div>
    {error && <div role="alert" style={{ ...css.card, borderColor: '#cf222e', color: '#cf222e', marginBottom: 12 }}>{error}</div>}
    {data === null ? (!error && <p style={css.muted}>Loading…</p>)
      : openId ? (current ? <Record key={current.id} u={current} data={data} onBack={() => go(null)} reload={load} />
        : <div style={css.card}>Account #{openId} is not among the 500 newest accounts. <a href="#/control">Back to all registrations</a></div>)
        : <Queue users={users} onOpen={go} />}
  </div>;
}
