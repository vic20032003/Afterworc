'use client';

import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';

const Admin = dynamic(() => import('../../client/src/admin/Admin.jsx'), {
  ssr: false,
  loading: () => <div className="loading">Loading…</div>
});

// Find work desk (open briefs): moderation of specialist applications and the
// anonymised listings. Shown at /admin#/find-work, inside the same staff-only
// page (the gateway authorizes /admin; the Go routes re-check the grant).
const BriefsDesk = dynamic(() => import('./briefs-desk.jsx'), {
  ssr: false,
  loading: () => <div className="loading">Loading…</div>
});

// Control Center: every registration and upload in one queue, and one record
// per person. It is where /admin opens; the staff console stays at /admin#/.
const ControlCenter = dynamic(() => import('./control-center.jsx'), {
  ssr: false,
  loading: () => <div className="loading">Loading…</div>
});

const DESK = '#/find-work';
const CONTROL = '#/control';
const pill = on => ({ padding: '9px 14px', borderRadius: 99, background: on ? '#fff' : '#065132', color: on ? '#065132' : '#fff', border: '1px solid #065132',
  font: '600 13px/1 Inter, system-ui, sans-serif', textDecoration: 'none', boxShadow: '0 6px 20px #0003' });

export default function AdminClient() {
  const [view, setView] = useState('console');
  useEffect(() => {
    // A bare /admin (the link in every staff alert e-mail) opens the Control Center.
    if (!window.location.hash) window.history.replaceState(null, '', CONTROL);
    const sync = () => { const h = window.location.hash; setView(h.startsWith(CONTROL) ? 'control' : h.startsWith(DESK) ? 'desk' : 'console'); };
    sync();
    window.addEventListener('hashchange', sync);
    return () => window.removeEventListener('hashchange', sync);
  }, []);
  return <>
    {view === 'control' ? <ControlCenter /> : view === 'desk' ? <BriefsDesk /> : <Admin />}
    <nav aria-label="Staff pages" style={{ position: 'fixed', right: 16, bottom: 16, zIndex: 50, display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
      <a href={CONTROL} style={pill(view === 'control')}>Control Center</a>
      <a href="#/" style={pill(view === 'console')}>Staff console</a>
      <a href={DESK} style={pill(view === 'desk')}>Find work desk</a>
    </nav>
  </>;
}
