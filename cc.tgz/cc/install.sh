#!/bin/bash
# AfterWorc Control Center: safe install on the live server.
# Changes only the website gateway (frontend). The API, database, mail and
# payment services are not rebuilt or restarted.
# Undo at any time:  bash /root/cc-20261110/rollback.sh
set -euo pipefail
umask 077
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=${AW_ROOT:-/srv/afterworc}
NEXT=$ROOT/src/frontend/next
CT=${AW_GATEWAY_CONTAINER:-awgo-gateway-1}
SITE=${AW_SITE:-https://afterworc.com}
STATE=$HERE/state.env
BK=$HERE/backup
say() { echo; echo "== $*"; }
die() { echo; echo "STOPPED: $*"; echo "Nothing on the live site was changed."; exit 1; }

[ -e "$STATE" ] && die "already installed (found $STATE). To undo: bash $HERE/rollback.sh"

say "1/7 Checking the server is the version this install was made for"
[ -d "$NEXT/components" ] || die "$NEXT/components not found"
sum() { sha256sum "$1" | cut -c1-12; }
[ "$(sum "$NEXT/components/admin-client.jsx")" = "${AW_SUM_ADMIN:-56bfc414fd32}" ] || die "admin-client.jsx is not the expected version (the site changed since 10 Nov)"
[ "$(sum "$NEXT/backend-routes.cjs")" = "${AW_SUM_ROUTES:-626f2cbb999e}" ] || die "backend-routes.cjs is not the expected version (the site changed since 10 Nov)"
[ -e "$NEXT/components/control-center.jsx" ] && die "control-center.jsx already exists on the server"
[ "$(grep -c 'Go-native browser reads referenced by the Go account state' "$NEXT/backend-routes.cjs")" = "1" ] || die "could not find the place for the new routes"
[ "$(grep -c 'api/staff/moderation' "$NEXT/backend-routes.cjs")" = "0" ] || die "the routes file already has moderation routes"
command -v python3 >/dev/null || die "python3 is not installed"
docker inspect "$CT" >/dev/null 2>&1 || die "container $CT not found"
label() { docker inspect "$CT" --format "{{index .Config.Labels \"$1\"}}"; }
OLD_IMAGE=$(docker inspect "$CT" --format '{{.Config.Image}}')
PROJECT=$(label com.docker.compose.project)
SERVICE=$(label com.docker.compose.service)
FILES=$(label com.docker.compose.project.config_files)
WORKDIR=$(label com.docker.compose.project.working_dir)
ENVFILE=$(label com.docker.compose.project.environment_file)
[ -n "$ENVFILE" ] || ENVFILE=$ROOT/production.env
ENVFILE=${ENVFILE%%,*}
{ [ -n "$OLD_IMAGE" ] && [ -n "$PROJECT" ] && [ -n "$SERVICE" ] && [ -n "$FILES" ]; } || die "could not read how the gateway was started"
[ -f "$ENVFILE" ] || die "settings file $ENVFILE not found"
case "$OLD_IMAGE" in *-cc1) die "the gateway already runs a Control Center build";; esac
NEW_IMAGE=$OLD_IMAGE-cc1
ARGS=(-p "$PROJECT" --env-file "$ENVFILE")
IFS=',' read -ra LIST <<< "$FILES"
for f in "${LIST[@]}"; do [ -f "$f" ] || die "compose file $f not found"; ARGS+=(-f "$f"); done
[ "$(docker inspect "$CT" --format '{{.State.Running}}')" = "true" ] || die "the gateway is not running right now; not touching it"
code() { curl -s -o /dev/null -m 20 -w '%{http_code}' "$1" || true; }
[ "$(code "$SITE/")" = "200" ] || die "the site does not answer 200 right now; not touching it"
FREE=$(df -Pm "$ROOT" | awk 'NR==2{print $4}')
[ "$FREE" -gt 5000 ] || die "less than 5 GB free disk"
# The new build must take its image name from AW_GATEWAY_IMAGE, or the old image would be overwritten.
AW_GATEWAY_IMAGE=$NEW_IMAGE docker compose "${ARGS[@]}" config 2>/dev/null | grep -q "image: $NEW_IMAGE" || die "the gateway image name cannot be set safely on this server"
echo "running image: $OLD_IMAGE   new image: $NEW_IMAGE   service: $SERVICE"

say "2/7 Backups (kept in $BK)"
mkdir -p "$BK"
cp -p "$NEXT/components/admin-client.jsx" "$NEXT/backend-routes.cjs" "$BK/"
cp -p "$ENVFILE" "$BK/production.env"
tar -C "$ROOT/src/frontend" --exclude=node_modules --exclude=.next -czf "$BK/frontend-next-before.tgz" next
docker image inspect "$OLD_IMAGE" >/dev/null || die "the running image $OLD_IMAGE is missing, so there would be no way back"
PG=$(docker ps --format '{{.Names}}' | grep -m1 postgres || true)
if [ -n "$PG" ] && docker exec "$PG" sh -c 'pg_dumpall -U "${POSTGRES_USER:-postgres}"' 2>/dev/null | gzip > "$BK/database-before.sql.gz" && [ "$(stat -c %s "$BK/database-before.sql.gz")" -gt 10000 ]; then
  echo "database copy: $(du -h "$BK/database-before.sql.gz" | cut -f1) (this install does not touch the database; the copy is extra safety)"
else
  rm -f "$BK/database-before.sql.gz"; echo "note: no database copy was made. This install does not touch the database."
fi
ls -la "$BK"

# From here on, any failure puts everything back automatically.
restore_files() {
  cp -p "$BK/admin-client.jsx" "$NEXT/components/admin-client.jsx"
  cp -p "$BK/backend-routes.cjs" "$NEXT/backend-routes.cjs"
  rm -f "$NEXT/components/control-center.jsx" "$NEXT/components/control-center-logic.mjs"
}
SWAPPED=0
undo() {
  trap - ERR INT TERM
  set +e
  echo; echo "!! Something failed. Putting everything back."
  restore_files
  if [ "$SWAPPED" = 1 ]; then
    cd "$WORKDIR" 2>/dev/null || cd /
    AW_GATEWAY_IMAGE=$OLD_IMAGE docker compose "${ARGS[@]}" up -d --no-deps "$SERVICE" || echo "!! could not restart the old gateway automatically. Run: bash $HERE/rollback.sh"
    sleep 20; echo "site answers: $(code "$SITE/")"
    rm -f "$HERE/rollback.env"
  fi
  echo "Rolled back. The site runs the old version ($OLD_IMAGE)."
  exit 1
}
trap undo ERR INT TERM

say "3/7 Adding the Control Center files"
cp "$HERE/components/control-center.jsx" "$HERE/components/control-center-logic.mjs" "$NEXT/components/"
cp "$HERE/components/admin-client.jsx" "$NEXT/components/admin-client.jsx"
chmod 644 "$NEXT/components/control-center.jsx" "$NEXT/components/control-center-logic.mjs" "$NEXT/components/admin-client.jsx"
python3 - "$NEXT/backend-routes.cjs" <<'PY'
import sys
p = sys.argv[1]; s = open(p).read()
mark = "  // Go-native browser reads referenced by the Go account state"
assert s.count(mark) == 1
add = """  // Control Center (staff): one account's review record, its specialist
  // profile and the two profile decisions. Go re-checks session, MFA, grants.
  ['/api/staff/moderation/accounts/{id}', '/api/staff/moderation/accounts/[0-9]{1,16}'],
  ['/api/staff/moderation/profiles/{id}', '/api/staff/moderation/profiles/[0-9]{1,16}'],
  ['/api/staff/moderation/profiles/{id}/publish', '/api/staff/moderation/profiles/[0-9]{1,16}/publish'],
  ['/api/staff/moderation/profiles/{id}/return', '/api/staff/moderation/profiles/[0-9]{1,16}/return'],
"""
open(p, "w").write(s.replace(mark, add + mark))
PY
[ "$(grep -c "api/staff/moderation" "$NEXT/backend-routes.cjs")" = "4" ]

say "4/7 Building the new gateway (the live site keeps running; takes a few minutes)"
cd "$WORKDIR" 2>/dev/null || cd "$ROOT/src"
AW_GATEWAY_IMAGE=$NEW_IMAGE docker compose "${ARGS[@]}" build "$SERVICE"
docker image inspect "$NEW_IMAGE" >/dev/null
docker image inspect "$OLD_IMAGE" >/dev/null

say "5/7 Switching the gateway to the new build (a few seconds)"
{ echo "OLD_IMAGE='$OLD_IMAGE'"; echo "NEW_IMAGE='$NEW_IMAGE'"; echo "PROJECT='$PROJECT'"; echo "SERVICE='$SERVICE'"; echo "FILES='$FILES'"; echo "WORKDIR='$WORKDIR'"; echo "ENVFILE='$ENVFILE'"; echo "NEXT='$NEXT'"; echo "SITE='$SITE'"; } > "$HERE/rollback.env"
SWAPPED=1
AW_GATEWAY_IMAGE=$NEW_IMAGE docker compose "${ARGS[@]}" up -d --no-deps "$SERVICE"

say "6/7 Checking the site"
ok=0
for _ in $(seq 1 36); do
  sleep "${AW_WAIT:-5}"
  st=$(docker inspect "$CT" --format '{{.State.Status}}/{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' 2>/dev/null || echo gone)
  home=$(code "$SITE/"); me=$(code "$SITE/api/auth/me"); adm=$(code "$SITE/admin")
  echo "  $st  home=$home  api=$me  admin=$adm"
  case "$st" in running/healthy|running/none) ;; *) continue;; esac
  [ "$home" = "200" ] || continue
  case "$me" in 200|401) ;; *) continue;; esac
  case "$adm" in 200|302|303|307|308) ;; *) continue;; esac
  ok=1; break
done
[ "$ok" = 1 ] || { echo "the site did not come back healthy in 3 minutes"; false; }
[ "$(docker inspect "$CT" --format '{{.Config.Image}}')" = "$NEW_IMAGE" ]

say "7/7 Saving the new version in the settings file"
trap - ERR INT TERM
if grep -q '^AW_GATEWAY_IMAGE=' "$ENVFILE"; then
  sed -i "s|^AW_GATEWAY_IMAGE=.*|AW_GATEWAY_IMAGE=$NEW_IMAGE|" "$ENVFILE"
else
  echo "note: AW_GATEWAY_IMAGE is not set in $ENVFILE; tell Boris the gateway image is now $NEW_IMAGE"
fi
mv "$HERE/rollback.env" "$STATE"
echo
echo "DONE. Control Center is live: $SITE/admin"
echo "To undo: bash $HERE/rollback.sh"
