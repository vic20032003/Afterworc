#!/bin/bash
# Puts the website gateway back exactly as it was before install.sh.
set -uo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
S=$HERE/state.env; [ -f "$S" ] || S=$HERE/rollback.env
[ -f "$S" ] || { echo "Nothing to undo: the install did not change the live site."; exit 0; }
# shellcheck disable=SC1090
. "$S"
BK=$HERE/backup
{ [ -f "$BK/admin-client.jsx" ] && [ -f "$BK/backend-routes.cjs" ]; } || { echo "Backup files are missing in $BK. Stop and call Boris."; exit 1; }
docker image inspect "$OLD_IMAGE" >/dev/null 2>&1 || { echo "The old image $OLD_IMAGE is gone. Stop and call Boris."; exit 1; }
echo "== Restoring the old files"
cp -p "$BK/admin-client.jsx" "$NEXT/components/admin-client.jsx"
cp -p "$BK/backend-routes.cjs" "$NEXT/backend-routes.cjs"
rm -f "$NEXT/components/control-center.jsx" "$NEXT/components/control-center-logic.mjs"
grep -q "^AW_GATEWAY_IMAGE=$NEW_IMAGE\$" "$ENVFILE" && sed -i "s|^AW_GATEWAY_IMAGE=.*|AW_GATEWAY_IMAGE=$OLD_IMAGE|" "$ENVFILE"
echo "== Starting the old gateway ($OLD_IMAGE)"
ARGS=(-p "$PROJECT" --env-file "$ENVFILE")
IFS=',' read -ra LIST <<< "$FILES"
for f in "${LIST[@]}"; do ARGS+=(-f "$f"); done
cd "$WORKDIR" 2>/dev/null || cd /
AW_GATEWAY_IMAGE=$OLD_IMAGE docker compose "${ARGS[@]}" up -d --no-deps "$SERVICE" || { echo "Could not start the old gateway. Call Boris."; exit 1; }
c=000
for _ in $(seq 1 24); do sleep "${AW_WAIT:-5}"; c=$(curl -s -o /dev/null -m 20 -w '%{http_code}' "$SITE/" || true); echo "  site answers: $c"; [ "$c" = "200" ] && break; done
mv "$S" "$HERE/undone-$(date -u +%Y%m%dT%H%M%SZ).env"
[ "$c" = "200" ] && echo "UNDONE. The site runs the old version again." || echo "The old gateway was started but the site does not answer 200 yet. Call Boris."
